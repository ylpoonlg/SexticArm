# 6 Degree-of-Freedom Robot Arm
This project aims to build a 6DOF robot arm which is able to move to any given position and angle using inverse kinematics.

## Documentation
[docs](docs/6DOF.pdf)